import 'package:recipeappoff/recipe_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';


class DatabaseHelper {
  Database? _database;

  // Singleton
  static final DatabaseHelper instance = DatabaseHelper._init();

  DatabaseHelper._init();

  // Get the database
  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB('database.db');
    return _database!;
  }

  // Init database
  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  // Create the DB
  Future _createDB(Database db, int version) async {
    await db.execute('''
      create table recipes ( 
        id integer primary key autoincrement, 
        name text not null,
        description text not null,
        imagePath text
        )''');
  }

  // Insert recipe
  Future<int> insertRecipe(Recipe recipe) async {
    final db = await database;
    return await db.insert('recipes', recipe.toMap());
  }

  // Get all recipes
  Future<List<Recipe>> getAllRecipes() async {
    final db = await instance.database;

    final result = await db.query('recipes');

    return result.map((json) => Recipe.fromJSON(json)).toList();
  }

  // Delete
  Future<void> delete(int id) async {
    try {
      final db = await instance.database;

      await db.delete(
        'recipes',
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (_) {}
  }

  // Update
  Future<int> update(Recipe recipe) async {
    final db = await instance.database;

    return db.update(
      'recipes',
      recipe.toMap(),
      where: 'id = ?',
      whereArgs: [recipe.id],
    );
  }

  // Close the database
  Future close() async {
    final db = await instance.database;

    db.close();
  }
}
