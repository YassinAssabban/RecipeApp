import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'database_helper.dart';
import 'recipe_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:io';


class AddRecipe extends StatefulWidget {
  const AddRecipe({super.key, this.recipe});
  final Recipe? recipe;


  @override
  State<AddRecipe> createState() => _AddRecipeState();
}

class _AddRecipeState extends State<AddRecipe> {
  // Form
  final nameController = TextEditingController();
  final descriptionController = TextEditingController();
  final imageController = TextEditingController();

  File? image; // Image

  // Dispose
  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  // Add a recipe
  Future<void> addRecipe() async {
    Recipe recipe = Recipe(
      name: nameController.text,
      description: descriptionController.text,
      imagePath: image != null ? image!.path : null,
    );

    if (widget.recipe == null) {
      await DatabaseHelper.instance.insertRecipe(recipe);
    } else {
      recipe.id = widget.recipe!.id;
      await DatabaseHelper.instance.update(recipe);
    }

    void addRecipeData() {
      if (widget.recipe != null && mounted) {
        setState(() {
          nameController.text = widget.recipe!.name;
          descriptionController.text = widget.recipe!.description;
          imageController.text = widget.recipe!.imagePath ?? '';
        });
      }
    }

  @override
  void initState() {
  addRecipeData();
  super.initState();
  }
}

Future<void> pickImage() async {
    try {
      // Récupérer l'image
      final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        setState(() {
          image = File(pickedFile.path);
          imageController.text = image!.path;
        });
      }
    } catch (e) {
      debugPrint(e.toString());
    }
}

    // Build
    @override
      Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Ajouter recette'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Nom',
                  hintText: 'Nom de la recette',
                ),
              ),
              const SizedBox(height: 36),
              TextFormField(
                controller: descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  hintText: 'Description de la recette',
                ),
              ),
              const SizedBox(height: 36),
              TextFormField(
                controller: imageController,
                decoration: const InputDecoration(
                  labelText: 'Image',
                  hintText: 'Sélectionner depuis la galerie',
                ),
                onTap: pickImage, // Appeler la méthode _pickImage lorsqu'on appuie sur le champ
              ),
              const SizedBox(height: 16),
              MaterialButton(onPressed: ()
              {
                addRecipe();
                Navigator.pop(context);
              },
              child: const Text('Ajouter'),
              )
            ]
          ),
        ),
        );
    }
   }