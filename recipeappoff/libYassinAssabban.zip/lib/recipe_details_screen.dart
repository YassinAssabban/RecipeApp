import 'dart:io';
import 'package:flutter/material.dart';
import 'recipe_model.dart';

class RecipeDetailScreen extends StatelessWidget {
  final Recipe recipe;

  const RecipeDetailScreen({Key? key, required this.recipe}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(recipe.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image de la recette
            SizedBox(
              height: 200,
              child: recipe.imagePath != null
                  ? Image.file(File(recipe.imagePath!))
                  : Text('Pas d\'image'),
            ),
            const SizedBox(height: 16),
            // Description de la recette
            const Text(
              'Description:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(recipe.description),
            const SizedBox(height: 16),
            // Liste des ingrédients
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Ingrédients:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  for (final ingredient in recipe.ingredients)
                    Text(ingredient.name),
                    Text("Cream"),
                    Text("Chicken"),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
