import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:recipeappoff/utility.dart';
import 'database_helper.dart';
import 'recipe_model.dart';


class AddRecipe extends StatefulWidget {
  const AddRecipe({super.key, this.recipe});
  final Recipe? recipe;


  @override
  State<AddRecipe> createState() => _AddRecipeState();
}

class _AddRecipeState extends State<AddRecipe> {
  // Form
  final nameController = TextEditingController();
  final descriptionController = TextEditingController();

  // Dispose
  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  // Add a recipe
  Future<void> addRecipe() async {
    Recipe recipe = Recipe(
      name: nameController.text,
      description: descriptionController.text,
    );

    if (widget.recipe == null) {
      await DatabaseHelper.instance.insertRecipe(recipe);
    } else {
      recipe.id = widget.recipe!.id;
      await DatabaseHelper.instance.update(recipe);
    }

    void addRecipeData() {
      if (widget.recipe != null && mounted) {
        setState(() {
          nameController.text = widget.recipe!.name;
          descriptionController.text = widget.recipe!.description;
        });
      }
    }
  @override
  void initState() {
  addRecipeData();
  super.initState();
  }
}

    // Build
    @override
      Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Ajouter recette'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Nom',
                  hintText: 'Nom de la recette',
                ),
              ),
              const SizedBox(height: 36),
              TextFormField(
                controller: descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  hintText: 'Description de la recette',
                ),
              ),
              const SizedBox(height: 36),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(36),
                  child: Column(
                    children: [
                      Center(
                        child: GestureDetector(
                          child: const Text('Choissisez une image'),
                          onTap: () => (),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              MaterialButton(onPressed: ()
              {
                addRecipe();
                Navigator.pop(context);
              },
              child: const Text('Ajouter'),
              )
            ]
          ),
        ),
        );
    }
   }